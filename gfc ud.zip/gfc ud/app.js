require('dotenv').config();
const express        = require('express');
const session        = require('express-session');
const cors           = require('cors');
const path           = require('path');

const verifyRouter   = require('./routes/verify');
const reportsRouter  = require('./routes/reports');
const feedbackRouter = require('./routes/feedback');
const adminRouter    = require('./routes/admin');

const app = express();
const PORT = process.env.PORT || 3000;

// ─── MIDDLEWARE ───────────────────────────────────────────────
app.use(cors());
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(express.static(path.join(__dirname, 'public')));

app.use(session({
  secret: process.env.SESSION_SECRET || 'gctu_secret_2025',
  resave: false,
  saveUninitialized: false,
  cookie: { secure: false, maxAge: 24 * 60 * 60 * 1000 }
}));

// ─── API ROUTES ───────────────────────────────────────────────
app.use('/api/verify',   verifyRouter);
app.use('/api/reports',  reportsRouter);
app.use('/api/feedback', feedbackRouter);
app.use('/api/admin',    adminRouter);

// ─── PAGE ROUTES ─────────────────────────────────────────────
app.get('/',          (_, res) => res.sendFile(path.join(__dirname, 'public/index.html')));
app.get('/report',    (_, res) => res.sendFile(path.join(__dirname, 'public/report.html')));
app.get('/feed',      (_, res) => res.sendFile(path.join(__dirname, 'public/feed.html')));
app.get('/admin',     (_, res) => res.sendFile(path.join(__dirname, 'public/admin/login.html')));
app.get('/admin/dashboard', (req, res) => {
  if (!req.session.adminLoggedIn) return res.redirect('/admin');
  res.sendFile(path.join(__dirname, 'public/admin/dashboard.html'));
});

app.listen(PORT, () => {
  console.log(`\n🚀 GCTU FactCheck running at http://localhost:${PORT}`);
  console.log(`   Admin panel: http://localhost:${PORT}/admin\n`);
});
