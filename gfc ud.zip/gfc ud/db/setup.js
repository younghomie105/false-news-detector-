// db/setup.js
// Run this once with: node db/setup.js
// Creates all tables and seeds with dummy GCTU data

// Use the compatibility wrapper (same API as better-sqlite3)
const db = require('./index');
const bcrypt = require('bcryptjs');


console.log('🛠  Setting up FactCheck GCTU database...\n');

// ─── CREATE TABLES ───────────────────────────────────────────

db.exec(`
  -- Knowledge Base: verified GCTU announcements
  CREATE TABLE IF NOT EXISTS knowledge_base (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    title TEXT NOT NULL,
    content TEXT NOT NULL,
    category TEXT NOT NULL DEFAULT 'general',
    source TEXT NOT NULL,
    source_url TEXT,
    date_published TEXT,
    date_added TEXT DEFAULT (datetime('now')),
    added_by TEXT DEFAULT 'admin',
    is_verified INTEGER DEFAULT 1,
    status TEXT DEFAULT 'active'
  );

  -- Fake News Database: confirmed false news
  CREATE TABLE IF NOT EXISTS fake_news (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    title TEXT NOT NULL,
    content TEXT NOT NULL,
    category TEXT NOT NULL DEFAULT 'general',
    why_false TEXT NOT NULL,
    source_of_rumour TEXT,
    date_debunked TEXT DEFAULT (datetime('now')),
    added_by TEXT DEFAULT 'admin',
    status TEXT DEFAULT 'active'
  );

  -- Student Reports: news submitted by students for checking
  CREATE TABLE IF NOT EXISTS reports (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    title TEXT NOT NULL,
    content TEXT NOT NULL,
    where_seen TEXT,
    submitted_by TEXT DEFAULT 'anonymous',
    date_submitted TEXT DEFAULT (datetime('now')),
    verdict TEXT DEFAULT 'pending',
    admin_note TEXT,
    verified_by TEXT,
    date_verified TEXT
  );

  -- Verification Logs: every check performed
  CREATE TABLE IF NOT EXISTS verification_logs (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    query TEXT NOT NULL,
    result TEXT NOT NULL,
    source_used TEXT,
    explanation TEXT,
    date_checked TEXT DEFAULT (datetime('now'))
  );

  -- Admin Users
  CREATE TABLE IF NOT EXISTS admins (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    username TEXT UNIQUE NOT NULL,
    password_hash TEXT NOT NULL,
    role TEXT DEFAULT 'moderator',
    date_created TEXT DEFAULT (datetime('now'))
  );
`);

console.log('✅ Tables created\n');

// ─── SEED KNOWLEDGE BASE ──────────────────────────────────────

const kbInsert = db.prepare(`
  INSERT OR IGNORE INTO knowledge_base (title, content, category, source, source_url, date_published)
  VALUES (?, ?, ?, ?, ?, ?)
`);

const knowledgeBaseData = [
  [
    'Second Semester Examinations Begin March 17, 2025',
    'GCTU has officially scheduled the commencement of second semester examinations for March 17, 2025. All students are expected to check the official examination timetable on the student portal. Examinations will run until April 4, 2025.',
    'exams',
    'GCTU Official Website',
    'https://gctu.edu.gh',
    'March 1, 2025'
  ],
  [
    'GCTU Technology and Innovation Fair - April 2, 2025',
    'The annual GCTU Technology and Innovation Fair is scheduled for April 2, 2025 at the Main Campus Auditorium. All departments and student groups are encouraged to participate. Registration closes March 25.',
    'events',
    'GCTU Social Media',
    'https://gctu.edu.gh/events',
    'February 28, 2025'
  ],
  [
    'Second Semester 2024/25 Registration Deadline Extended',
    'GCTU Registrar\'s Office has officially extended the second semester registration deadline by one week to February 28, 2025. Students who have not completed their registration should do so before the new deadline to avoid late fees.',
    'academic',
    'GCTU Registrar Office',
    'https://gctu.edu.gh',
    'February 20, 2025'
  ],
  [
    'Mid-Semester Break: March 10-14, 2025',
    'According to the 2024/25 Academic Calendar, the mid-semester break runs from Monday March 10 to Friday March 14, 2025. Students are expected to resume academic work on Monday March 17.',
    'academic',
    'GCTU Academic Calendar',
    'https://gctu.edu.gh/calendar',
    'January 15, 2025'
  ],
  [
    '2025/2026 Academic Calendar Released',
    'GCTU has officially released the 2025/2026 Academic Calendar. Students can download it from the official student portal under the Resources section. The new academic year begins September 1, 2025.',
    'academic',
    'GCTU Official Website',
    'https://gctu.edu.gh',
    'February 14, 2025'
  ],
  [
    'New Campus Shuttle Bus Routes Effective March 1',
    'GCTU Transport Management has officially announced two new shuttle bus routes effective March 1, 2025. Route A covers Atomic Junction to Main Campus and Route B covers Madina to Main Campus. Service runs 6AM to 8PM on weekdays.',
    'campus',
    'GCTU Transport Management',
    null,
    'February 25, 2025'
  ],
  [
    'School Fees Payment Deadline for Second Semester',
    'The deadline for second semester 2024/25 school fees payment is March 31, 2025. Students with outstanding fees after this date will be restricted from accessing the student portal and writing examinations.',
    'fees',
    'GCTU Finance Office',
    'https://gctu.edu.gh/finance',
    'February 10, 2025'
  ],
  [
    'Faculty of Computing Final Year Project Submission',
    'Faculty of Computing final year project submissions are due April 15, 2025. Students must submit both softcopy via the portal and hardcopy to the department. No extensions will be granted after this date.',
    'academic',
    'Faculty of Computing',
    null,
    'February 5, 2025'
  ],
  [
    'GCTU Library Hours: 7AM - 9PM Weekdays',
    'The GCTU Main Library operates from 7:00 AM to 9:00 PM Monday to Friday, and 9:00 AM to 5:00 PM on Saturdays. The library is closed on Sundays and public holidays.',
    'campus',
    'GCTU Library Services',
    null,
    'January 10, 2025'
  ],
  [
    'Student Portal Maintenance Scheduled for March 8, 2025',
    'GCTU ICT Directorate has announced scheduled maintenance on the student portal on Saturday March 8, 2025 from 12AM to 6AM. Services will be temporarily unavailable during this period.',
    'campus',
    'GCTU ICT Directorate',
    null,
    'March 3, 2025'
  ]
];

const kbTransaction = db.transaction((data) => {
  for (const row of data) kbInsert.run(...row);
});
kbTransaction(knowledgeBaseData);
console.log(`✅ Seeded ${knowledgeBaseData.length} knowledge base entries\n`);

// ─── SEED FAKE NEWS DATABASE ───────────────────────────────────

const fakeInsert = db.prepare(`
  INSERT OR IGNORE INTO fake_news (title, content, category, why_false, source_of_rumour)
  VALUES (?, ?, ?, ?, ?)
`);

const fakeNewsData = [
  [
    'GCTU School Fees to Triple Next Semester',
    'A message claiming that GCTU school fees will triple starting next semester has been circulating on WhatsApp.',
    'fees',
    'GCTU Finance Office has confirmed that no fee changes have been announced for the upcoming semester. The official fee schedule remains unchanged.',
    'WhatsApp'
  ],
  [
    'Head of CS Department Arrested on Campus',
    'A rumour claiming that the Head of the Computer Science Department was arrested on campus has been spreading on social media.',
    'campus',
    'GCTU Security and Administration have confirmed this is completely false. No such incident occurred.',
    'Facebook'
  ],
  [
    'GCTU Internet to Be Shut Down This Week',
    'A message claiming GCTU campus internet will be shut down for the entire week due to unpaid bills.',
    'campus',
    'ICT Directorate has denied this claim. No internet shutdown is scheduled. Any maintenance will be announced officially.',
    'WhatsApp'
  ],
  [
    'Final Year Project Deadline Moved to May 2025',
    'Students circulating a message claiming the FYP submission deadline has been moved to May.',
    'academic',
    'Faculty of Computing confirms the deadline remains April 15, 2025 as officially communicated. No extension has been granted.',
    'WhatsApp Group'
  ],
  [
    'GCTU to Shut Down for Two Weeks Due to Meningitis Outbreak',
    'A viral message claiming GCTU will shut down for two weeks due to a meningitis outbreak on campus.',
    'health',
    'GCTU Health Services and Administration confirm there is no meningitis outbreak. The university is operating normally.',
    'Twitter/X'
  ]
];

const fakeTransaction = db.transaction((data) => {
  for (const row of data) fakeInsert.run(...row);
});
fakeTransaction(fakeNewsData);
console.log(`✅ Seeded ${fakeNewsData.length} fake news entries\n`);

// ─── SEED ADMIN USER ───────────────────────────────────────────

const existingAdmin = db.prepare('SELECT id FROM admins WHERE username = ?').get('admin');
if (!existingAdmin) {
  const hash = bcrypt.hashSync('gctu@admin2025', 10);
  db.prepare('INSERT INTO admins (username, password_hash, role) VALUES (?, ?, ?)').run('admin', hash, 'super_admin');
  console.log('✅ Admin user created');
  console.log('   Username: admin');
  console.log('   Password: gctu@admin2025\n');
} else {
  console.log('ℹ️  Admin user already exists\n');
}

console.log('🎉 Database setup complete! Run: npm start\n');
db.close();
