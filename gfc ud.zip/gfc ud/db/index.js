// db/index.js
// Pure WebAssembly SQLite — zero C++ compilation, works on Windows/Mac/Linux.
// Wraps node-sqlite3-wasm with a better-sqlite3-compatible API so all
// existing routes (verify.js, admin.js, etc.) work without any changes.

const { Database: WasmDatabase } = require('node-sqlite3-wasm');
const path = require('path');

const rawDb = new WasmDatabase(path.join(__dirname, 'factcheck.db'));

// Helper: normalise spread-or-array params into a flat array
// better-sqlite3 uses spread: stmt.run(a, b, c)
// node-sqlite3-wasm expects: stmt.run([a, b, c])
function norm(args) {
  if (args.length === 0) return [];
  if (args.length === 1 && Array.isArray(args[0])) return args[0];
  return args;
}

// Wrap every prepared statement to accept spread args
function wrapStmt(stmt) {
  return {
    all(...args)  { return stmt.all(norm(args));  },
    get(...args)  { return stmt.get(norm(args));  },
    run(...args)  { return stmt.run(norm(args));  },
    bind(...args) { stmt.bind(norm(args)); return this; },
    free()        { stmt.free?.(); }
  };
}

const db = {
  prepare(sql)    { return wrapStmt(rawDb.prepare(sql)); },
  exec(sql)       { rawDb.exec(sql); return this; },
  pragma()        { return this; },   // no-op — not needed for WAL in WASM
  close()         { rawDb.close(); },

  // better-sqlite3 transaction: accepts a fn, returns a wrapper fn to call
  transaction(fn) {
    return function(...args) {
      rawDb.exec('BEGIN');
      try {
        fn(...args);
        rawDb.exec('COMMIT');
      } catch (e) {
        rawDb.exec('ROLLBACK');
        throw e;
      }
    };
  }
};

module.exports = db;
