
npm install

# 2. Set up your API keys in .env
#    (see .env for required keys)

# 3. Create the database (run once)
node db/setup.js

# 4. Start the server
npm start
# Or for development with hot-reload:
npm run dev
```

Then open: **http://localhost:3000**

## 🔑 API Keys Required

Edit `.env` and fill in your keys:

| Key | Where to get it | Required? |
|-----|----------------|-----------|
| `GROQ_API_KEY` | https://console.groq.com | Yes (for AI fact-checking) |
| `TAVILY_API_KEY` | https://app.tavily.com | Optional (enables live web search) |

---

## 📄 Pages

| URL | Description |
|-----|-------------|
| `/` | Home — AI fact-checker |
| `/report` | Report suspicious news / leave feedback |
| `/feed` | Public verification feed |
| `/admin` | Admin login |
| `/admin/dashboard` | Admin dashboard (requires login) |

---

## 🔐 Admin Credentials (Default)

```
Username: admin
Password: gctu@admin2025
```

**Change the password** by editing `db/setup.js` before running setup,
or update directly in the database.

---

## 🧠 How AI Verification Works

**Layer 1 — GCTU Knowledge Base (Groq AI Semantic Match)**
- Loads all verified facts + confirmed fake news from the local SQLite database
- Groq AI (LLaMA 3.3 70B) semantically matches the claim — not just keywords
- Returns `true`, `false`, or skips to Layer 2

**Layer 2 — Live Web Search + Groq Reasoning**
- Tavily searches the live internet for the claim + "GCTU Ghana"
- Groq AI reasons over the results
- Falls back to Groq knowledge-only if Tavily key is not set

**Fallback — Admin Queue**
- If both AI layers cannot verify, the claim is added to the pending reports queue for manual admin review

---

## 🗂️ Project Structure

```
factcheck-gctu/
├── app.js              # Express server entry point
├── .env                # API keys and config
├── db/
│   ├── index.js        # SQLite WASM wrapper
│   └── setup.js        # DB creation + seeding
├── routes/
│   ├── verify.js       # AI fact-check endpoint
│   ├── reports.js      # Student report submissions
│   ├── feedback.js     # Feedback system
│   └── admin.js        # Admin CRUD + auth
└── public/
    ├── index.html      # Home / fact-checker
    ├── report.html     # Report & feedback
    ├── feed.html       # Public verification feed
    └── admin/
        ├── login.html  # Admin login
        └── dashboard.html  # Full admin dashboard
```

---

## 📦 Tech Stack

- **Backend:** Node.js + Express
- **Database:** SQLite (via node-sqlite3-wasm — no native compilation)
- **AI:** Groq API (LLaMA 3.3 70B)
- **Web Search:** Tavily API
- **Auth:** bcryptjs + express-session
- **Frontend:** Vanilla HTML/CSS/JS — no build step needed
