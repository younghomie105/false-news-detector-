// routes/verify.js
// ARCHITECTURE:
// Layer 1: GCTU Database — Groq AI Semantic Match
//          Groq reads ALL entries (true + false) and matches by meaning, not keywords
//          If Groq is unavailable, Layer 1 is skipped entirely — no keyword guessing
// Layer 2: Tavily Web Search + Groq AI Reasoning
//          Tavily searches the live internet → Groq reasons over the results
//          Falls back to Groq knowledge-only if Tavily key is not set
// Admin Queue: only reached if both AI layers fail

const express    = require('express');
const router     = express.Router();
const axios      = require('axios');
const db         = require('../db');
const { tavily } = require('@tavily/core');

// ─── CONSTANTS ────────────────────────────────────────────────
const GROQ_MODEL       = process.env.GROQ_MODEL || 'llama-3.3-70b-versatile';
const CHUNK_CHAR_LIMIT = 3000;
const CHUNK_OVERLAP    = 2;
const EARLY_EXIT_CONF  = 0.9;

// ─── MAIN VERIFICATION ENDPOINT ──────────────────────────────
router.post('/', async (req, res) => {
  const { query } = req.body;

  if (!query || query.trim().length < 5) {
    return res.status(400).json({ error: 'Please provide a news headline or content to verify.' });
  }

  const trimmedQuery = query.trim();

  try {
    console.log('\n Verifying: "' + trimmedQuery + '"');

    // ── LAYER 1: GCTU DB — Groq AI Semantic Match ─────────────
    console.log('   Layer 1: GCTU AI semantic match...');
    const dbResult = await checkAIAgainstDatabase(trimmedQuery);
    if (dbResult && dbResult.verdict !== 'unverified') {
      logVerification(trimmedQuery, dbResult.verdict, dbResult.source, dbResult.explanation);
      return res.json(dbResult);
    }

    // ── LAYER 2: Tavily Web Search + Groq AI Reasoning ────────
    console.log('   Layer 2: Tavily web search + Groq AI reasoning...');
    const internetResult = await checkWithInternetAndAI(trimmedQuery);
    if (internetResult && internetResult.verdict !== 'unverified') {
      logVerification(trimmedQuery, internetResult.verdict, internetResult.source, internetResult.explanation);
      return res.json(internetResult);
    }

    // ── FALLBACK: Both layers found nothing → Admin Queue ──────
    console.log('   Unverified — sending to admin queue');
    addToReportsQueue(trimmedQuery);
    const unverifiedResult = {
      verdict:     'unverified',
      explanation: 'This news could not be verified through our GCTU knowledge base or internet sources. It has been forwarded to our admin team for manual review.',
      source:      'Admin Queue',
      confidence:  'low'
    };
    logVerification(trimmedQuery, 'unverified', 'None — sent to admin queue', unverifiedResult.explanation);
    return res.json(unverifiedResult);

  } catch (error) {
    console.error('Verification error:', error.message);
    return res.json({
      verdict:     'unverified',
      explanation: 'Verification service temporarily unavailable. Your query has been logged for manual review.',
      source:      'System Error — Admin Notified',
      confidence:  'low'
    });
  }
});

// ═══════════════════════════════════════════════════════════════
// LAYER 1 — GCTU DATABASE — GROQ AI SEMANTIC MATCH
// ═══════════════════════════════════════════════════════════════

async function checkAIAgainstDatabase(query) {
  try {
    const apiKey = process.env.GROQ_API_KEY;
    if (!apiKey || apiKey === 'your_groq_api_key_here') {
      console.log('   No Groq key — skipping Layer 1');
      return null;
    }

    const fakeNews      = db.prepare("SELECT title, content, why_false FROM fake_news WHERE status = 'active'").all();
    const knowledgeBase = db.prepare("SELECT title, content, source FROM knowledge_base WHERE status = 'active' AND is_verified = 1").all();

    if (fakeNews.length === 0 && knowledgeBase.length === 0) {
      console.log('   DB is empty — skipping Layer 1');
      return null;
    }

    const allEntries = [
      ...fakeNews.map(f => ({
        type: 'FAKE',
        text: '[FAKE] "' + f.title + '" — Why false: ' + (f.why_false || '')
      })),
      ...knowledgeBase.map(k => ({
        type: 'TRUE',
        text: '[TRUE] "' + k.title + '" — ' + (k.content || '').substring(0, 150)
      }))
    ];

    const totalChars = allEntries.reduce((sum, e) => sum + e.text.length, 0);

    // ── Small DB: single Groq call ─────────────────────────────
    if (totalChars <= CHUNK_CHAR_LIMIT) {
      console.log('   DB small (' + totalChars + ' chars) — single Groq call');
      return await runAIDbCheck(query, allEntries);
    }

    // ── Large DB: relevance pre-sort + chunking ────────────────
    console.log('   DB large (' + totalChars + ' chars) — chunking with relevance pre-filter');

    const queryLower = query.toLowerCase();
    const queryWords = queryLower.split(/\s+/).filter(w => w.length > 3);

    // Sort entries so most keyword-relevant ones go into the first chunk
    const scored = allEntries
      .map(entry => {
        const entryLower = entry.text.toLowerCase();
        const matches    = queryWords.filter(w => entryLower.includes(w)).length;
        return { ...entry, score: matches };
      })
      .sort((a, b) => b.score - a.score);

    const chunks = [];
    let current      = [];
    let currentChars = 0;

    for (const entry of scored) {
      if (currentChars + entry.text.length > CHUNK_CHAR_LIMIT && current.length > 0) {
        chunks.push([...current]);
        current      = current.slice(-CHUNK_OVERLAP);
        currentChars = current.reduce((s, e) => s + e.text.length, 0);
      }
      current.push(entry);
      currentChars += entry.text.length;
    }
    if (current.length > 0) chunks.push(current);

    console.log('   Split into ' + chunks.length + ' chunk(s)');

    let bestResult = null;

    for (let i = 0; i < chunks.length; i++) {
      console.log('   Chunk ' + (i + 1) + '/' + chunks.length + '...');
      const result = await runAIDbCheck(query, chunks[i]);
      if (!result || result.verdict === 'unverified') continue;

      const confScore = result.confidence === 'high'   ? 1.0
                      : result.confidence === 'medium' ? 0.6
                      : 0.3;

      if (confScore >= EARLY_EXIT_CONF) {
        console.log('   Early exit at chunk ' + (i + 1) + ' (confidence: ' + result.confidence + ')');
        return result;
      }

      const bestScore = !bestResult                        ? 0
                      : bestResult.confidence === 'high'   ? 1.0
                      : bestResult.confidence === 'medium' ? 0.6
                      : 0.3;

      if (confScore > bestScore) bestResult = result;
    }

    // Return best AI result found, or null to fall through to Layer 2
    return bestResult;

  } catch (err) {
    console.log('   Layer 1 error:', err.message);
    return null;
  }
}

// Single Groq call against one chunk (or full DB if small)
async function runAIDbCheck(query, entries) {
  try {
    const apiKey = process.env.GROQ_API_KEY;
    if (!apiKey || apiKey === 'your_groq_api_key_here') return null;

    const fakeSection = entries.filter(e => e.type === 'FAKE').map(e => e.text).join('\n') || '(none)';
    const trueSection = entries.filter(e => e.type === 'TRUE').map(e => e.text).join('\n') || '(none)';

    const prompt =
      'You are a fact-checker for Ghana Communication Technology University (GCTU).\n\n' +
      'CLAIM TO CHECK: "' + query + '"\n\n' +
      'Decide if this claim semantically matches any entry below.\n' +
      'Do NOT require exact words — match by meaning and intent.\n' +
      'If the user rephrases or paraphrases the news differently, still identify the match.\n\n' +
      '── GCTU KNOWN FALSE NEWS ──\n' + fakeSection + '\n\n' +
      '── GCTU VERIFIED TRUE NEWS ──\n' + trueSection + '\n\n' +
      'Rules:\n' +
      '- Claim matches a FAKE entry → verdict: "false"\n' +
      '- Claim matches a TRUE entry → verdict: "true"\n' +
      '- No clear semantic match → verdict: "unverified"\n' +
      '- Only say true/false when genuinely confident\n' +
      '- Explanation: 2 sentences max\n\n' +
      'Respond ONLY in this exact JSON format (no extra text):\n' +
      '{"verdict":"true" or "false" or "unverified","explanation":"...","matched_entry":"entry title or null","confidence":"high" or "medium" or "low"}';

    const response = await axios.post(
      'https://api.groq.com/openai/v1/chat/completions',
      {
        model:       GROQ_MODEL,
        messages:    [{ role: 'user', content: prompt }],
        max_tokens:  300,
        temperature: 0.1
      },
      {
        headers: { Authorization: 'Bearer ' + apiKey, 'Content-Type': 'application/json' },
        timeout: 15000
      }
    );

    const text = response.data?.choices?.[0]?.message?.content;
    if (!text) return null;

    const jsonMatch = text.match(/\{[\s\S]*\}/);
    if (!jsonMatch) return null;
    const parsed = JSON.parse(jsonMatch[0]);
    if (!parsed.verdict || !['true', 'false', 'unverified'].includes(parsed.verdict)) return null;

    console.log('   Layer 1 verdict: ' + parsed.verdict + ' (' + (parsed.confidence || 'medium') + ')');
    return {
      verdict:       parsed.verdict,
      explanation:   parsed.explanation   || 'Matched by AI against GCTU knowledge base.',
      source:        'GCTU AI Semantic Match',
      matched_entry: parsed.matched_entry || null,
      confidence:    parsed.confidence    || 'medium'
    };
  } catch (err) {
    console.log('   runAIDbCheck error:', err.message);
    return null;
  }
}

// ═══════════════════════════════════════════════════════════════
// LAYER 2 — TAVILY WEB SEARCH + GROQ AI REASONING
// ═══════════════════════════════════════════════════════════════

async function checkWithInternetAndAI(query) {
  // Primary: Tavily search → Groq reasoning
  const tavilyResult = await checkWithTavilyAndGroq(query);
  if (tavilyResult) return tavilyResult;

  // Fallback: Groq using its own training knowledge (no web search)
  console.log('   Tavily unavailable — falling back to Groq knowledge');
  return checkWithGroqKnowledge(query);
}

// Tavily searches the live web, Groq reasons over the results
async function checkWithTavilyAndGroq(query) {
  try {
    const tavilyKey = process.env.TAVILY_API_KEY;
    if (!tavilyKey || tavilyKey === 'your_tavily_api_key_here') return null;

    const groqKey = process.env.GROQ_API_KEY;
    if (!groqKey || groqKey === 'your_groq_api_key_here') return null;

    // ── Step 1: Tavily web search ──────────────────────────────
    console.log('   Tavily searching the web...');
    const client    = tavily({ apiKey: tavilyKey });
    const tavilyRes = await client.search(query + ' Ghana GCTU', {
      searchDepth: 'advanced',
      maxResults:  5
    });

    // Build context from Tavily answer + top result snippets
    let webContext = '';
    if (tavilyRes.answer && tavilyRes.answer.length > 20) {
      webContext += 'Summary: ' + tavilyRes.answer + '\n\n';
    }
    if (tavilyRes.results && tavilyRes.results.length > 0) {
      webContext += 'Search Results:\n';
      tavilyRes.results.slice(0, 4).forEach((r, i) => {
        if (r.content) {
          webContext += (i + 1) + '. [' + (r.title || 'Source') + '] ' + r.content.substring(0, 300) + '\n';
        }
      });
    }

    if (!webContext.trim()) {
      console.log('   Tavily returned no usable content');
      return null;
    }

    const topUrl = (tavilyRes.results && tavilyRes.results[0] && tavilyRes.results[0].url) || null;

    // ── Step 2: Groq reasons over Tavily results ───────────────
    console.log('   Groq reasoning over Tavily results...');
    const prompt =
      'You are a strict fact-checker for Ghana Communication Technology University (GCTU).\n\n' +
      'CLAIM TO VERIFY: "' + query + '"\n\n' +
      'LIVE WEB SEARCH RESULTS:\n' + webContext + '\n' +
      'Based ONLY on the search results above, determine if the claim is TRUE, FALSE, or UNVERIFIED.\n\n' +
      'Rules:\n' +
      '- Only say TRUE or FALSE if the results clearly and directly support the verdict\n' +
      '- If results are vague, unrelated, or insufficient → say UNVERIFIED\n' +
      '- Keep explanation to 2-3 sentences\n\n' +
      'Respond ONLY in this exact JSON format:\n' +
      '{"verdict":"true" or "false" or "unverified","explanation":"...","confidence":"high" or "medium" or "low"}';

    const groqRes = await axios.post(
      'https://api.groq.com/openai/v1/chat/completions',
      {
        model:       GROQ_MODEL,
        messages:    [{ role: 'user', content: prompt }],
        max_tokens:  300,
        temperature: 0.1
      },
      {
        headers: { Authorization: 'Bearer ' + groqKey, 'Content-Type': 'application/json' },
        timeout: 15000
      }
    );

    const text = groqRes.data?.choices?.[0]?.message?.content;
    if (!text) return null;

    const jsonMatch = text.match(/\{[\s\S]*\}/);
    if (!jsonMatch) return null;
    const parsed = JSON.parse(jsonMatch[0]);
    if (!parsed.verdict || !['true', 'false', 'unverified'].includes(parsed.verdict)) return null;

    console.log('   Tavily+Groq verdict: ' + parsed.verdict + ' (' + (parsed.confidence || 'medium') + ')');
    return {
      verdict:     parsed.verdict,
      explanation: parsed.explanation || 'Verified using live web search.',
      source:      'Tavily Web Search + Groq AI',
      source_url:  topUrl,
      confidence:  parsed.confidence || 'medium'
    };

  } catch (err) {
    console.log('   Tavily+Groq error:', err.response ? JSON.stringify(err.response.data) : err.message);
    return null;
  }
}

// Groq fallback — uses training knowledge when Tavily is unavailable
async function checkWithGroqKnowledge(query) {
  try {
    const apiKey = process.env.GROQ_API_KEY;
    if (!apiKey || apiKey === 'your_groq_api_key_here') return null;

    const prompt =
      'You are a fact-checker for Ghana Communication Technology University (GCTU).\n\n' +
      'CLAIM: "' + query + '"\n\n' +
      'Using your own training knowledge, is this claim TRUE, FALSE, or UNVERIFIED?\n' +
      '- TRUE — you are confident it is accurate and can explain why\n' +
      '- FALSE — you are confident it is inaccurate and can explain why\n' +
      '- UNVERIFIED — you have insufficient knowledge to judge\n\n' +
      'Only say TRUE or FALSE if genuinely confident. Keep explanation to 2-3 sentences.\n\n' +
      'Respond ONLY in this exact JSON format:\n' +
      '{"verdict":"true" or "false" or "unverified","explanation":"...","confidence":"high" or "medium" or "low"}';

    const response = await axios.post(
      'https://api.groq.com/openai/v1/chat/completions',
      {
        model:       GROQ_MODEL,
        messages:    [{ role: 'user', content: prompt }],
        max_tokens:  300,
        temperature: 0.1
      },
      {
        headers: { Authorization: 'Bearer ' + apiKey, 'Content-Type': 'application/json' },
        timeout: 15000
      }
    );

    const text = response.data?.choices?.[0]?.message?.content;
    if (!text) return null;

    const jsonMatch = text.match(/\{[\s\S]*\}/);
    if (!jsonMatch) return null;
    const parsed = JSON.parse(jsonMatch[0]);
    if (!parsed.verdict || !['true', 'false', 'unverified'].includes(parsed.verdict)) return null;

    console.log('   Groq knowledge verdict: ' + parsed.verdict);
    return {
      verdict:     parsed.verdict,
      explanation: parsed.explanation || 'Analyzed using AI knowledge base.',
      source:      'AI Knowledge Base (Groq / LLaMA)',
      source_url:  null,
      confidence:  parsed.confidence || 'medium'
    };
  } catch (err) {
    console.log('   Groq knowledge error:', err.message);
    return null;
  }
}

// ═══════════════════════════════════════════════════════════════
// HELPERS
// ═══════════════════════════════════════════════════════════════

function logVerification(query, result, source, explanation) {
  try {
    db.prepare('INSERT INTO verification_logs (query, result, source_used, explanation) VALUES (?, ?, ?, ?)').run(query, result, source, explanation);
  } catch (e) { /* non-critical */ }
}

function addToReportsQueue(query) {
  try {
    db.prepare('INSERT INTO reports (title, content, where_seen, submitted_by) VALUES (?, ?, ?, ?)').run(
      query.substring(0, 100), query, 'Verification System', 'auto-check'
    );
  } catch (e) { /* non-critical */ }
}

router.get('/recent', (req, res) => {
  try {
    const logs = db.prepare('SELECT * FROM verification_logs ORDER BY date_checked DESC LIMIT 10').all();
    res.json(logs);
  } catch (e) {
    res.json([]);
  }
});

module.exports = router;
// Public stats endpoint (no auth needed)
router.get('/stats', (req, res) => {
  try {
    const total      = db.prepare('SELECT COUNT(*) as c FROM verification_logs').get().c;
    const trueCount  = db.prepare("SELECT COUNT(*) as c FROM verification_logs WHERE result = 'true'").get().c;
    const falseCount = db.prepare("SELECT COUNT(*) as c FROM verification_logs WHERE result = 'false'").get().c;
    res.json({ total, trueCount, falseCount });
  } catch (e) {
    res.json({ total: 0, trueCount: 0, falseCount: 0 });
  }
});
