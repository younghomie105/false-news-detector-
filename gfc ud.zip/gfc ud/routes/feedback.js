// routes/feedback.js
const express = require('express');
const router  = express.Router();
const db      = require('../db');

// Ensure feedback table exists
try {
  db.exec(`
    CREATE TABLE IF NOT EXISTS feedback (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      name TEXT DEFAULT 'anonymous',
      email TEXT,
      category TEXT DEFAULT 'general',
      message TEXT NOT NULL,
      rating INTEGER,
      date_submitted TEXT DEFAULT (datetime('now')),
      status TEXT DEFAULT 'unread'
    )
  `);
} catch (e) { /* already exists */ }

// Submit feedback (public)
router.post('/', (req, res) => {
  const { name, email, category, message, rating } = req.body;
  if (!message || message.trim().length < 5) {
    return res.status(400).json({ error: 'Message is required.' });
  }
  try {
    db.prepare(`
      INSERT INTO feedback (name, email, category, message, rating)
      VALUES (?, ?, ?, ?, ?)
    `).run(
      (name || 'anonymous').trim(),
      (email || '').trim(),
      (category || 'general').trim(),
      message.trim(),
      rating ? parseInt(rating) : null
    );
    res.json({ success: true, message: 'Thank you for your feedback!' });
  } catch (e) {
    res.status(500).json({ error: 'Failed to submit feedback.' });
  }
});

// Get all feedback (admin)
router.get('/', (req, res) => {
  if (!req.session.adminLoggedIn) return res.status(401).json({ error: 'Unauthorized' });
  try {
    const rows = db.prepare('SELECT * FROM feedback ORDER BY date_submitted DESC').all();
    res.json(rows);
  } catch (e) {
    res.json([]);
  }
});

// Mark feedback as read (admin)
router.put('/:id/read', (req, res) => {
  if (!req.session.adminLoggedIn) return res.status(401).json({ error: 'Unauthorized' });
  try {
    db.prepare("UPDATE feedback SET status = 'read' WHERE id = ?").run(req.params.id);
    res.json({ success: true });
  } catch (e) {
    res.status(500).json({ error: 'Failed to update.' });
  }
});

module.exports = router;
