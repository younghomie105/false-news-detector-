// routes/reports.js
const express = require('express');
const router  = express.Router();
const db      = require('../db');

// Submit a report (public)
router.post('/', (req, res) => {
  const { title, content, where_seen, submitted_by } = req.body;
  if (!title || !content) return res.status(400).json({ error: 'Title and content are required.' });

  try {
    db.prepare(`
      INSERT INTO reports (title, content, where_seen, submitted_by)
      VALUES (?, ?, ?, ?)
    `).run(title.trim(), content.trim(), (where_seen || '').trim(), (submitted_by || 'anonymous').trim());

    res.json({ success: true, message: 'Report submitted. Our team will review it shortly.' });
  } catch (e) {
    console.error('Report submit error:', e.message);
    res.status(500).json({ error: 'Failed to submit report.' });
  }
});

// Get recent verified reports (public feed)
router.get('/recent', (req, res) => {
  try {
    const rows = db.prepare(`
      SELECT id, title, verdict, admin_note, date_submitted, date_verified
      FROM reports
      WHERE verdict IN ('true', 'false')
      ORDER BY date_verified DESC
      LIMIT 20
    `).all();
    res.json(rows);
  } catch (e) {
    res.json([]);
  }
});

// Get all reports (admin)
router.get('/', (req, res) => {
  if (!req.session.adminLoggedIn) return res.status(401).json({ error: 'Unauthorized' });
  try {
    const rows = db.prepare('SELECT * FROM reports ORDER BY date_submitted DESC').all();
    res.json(rows);
  } catch (e) {
    res.json([]);
  }
});

// Update report verdict (admin)
router.put('/:id', (req, res) => {
  if (!req.session.adminLoggedIn) return res.status(401).json({ error: 'Unauthorized' });
  const { verdict, admin_note } = req.body;
  if (!verdict) return res.status(400).json({ error: 'Verdict required.' });

  try {
    db.prepare(`
      UPDATE reports
      SET verdict = ?, admin_note = ?, verified_by = ?, date_verified = datetime('now')
      WHERE id = ?
    `).run(verdict, admin_note || '', req.session.adminUser || 'admin', req.params.id);
    res.json({ success: true });
  } catch (e) {
    res.status(500).json({ error: 'Failed to update report.' });
  }
});

// Delete report (admin)
router.delete('/:id', (req, res) => {
  if (!req.session.adminLoggedIn) return res.status(401).json({ error: 'Unauthorized' });
  try {
    db.prepare('DELETE FROM reports WHERE id = ?').run(req.params.id);
    res.json({ success: true });
  } catch (e) {
    res.status(500).json({ error: 'Failed to delete report.' });
  }
});

module.exports = router;
