// routes/admin.js
const express  = require('express');
const router   = express.Router();
const bcrypt   = require('bcryptjs');
const db       = require('../db');

// ─── AUTH MIDDLEWARE ──────────────────────────────────────────
function requireAdmin(req, res, next) {
  if (!req.session.adminLoggedIn) return res.status(401).json({ error: 'Unauthorized' });
  next();
}

// ─── LOGIN / LOGOUT ───────────────────────────────────────────
router.post('/login', (req, res) => {
  const { username, password } = req.body;
  try {
    const admin = db.prepare('SELECT * FROM admins WHERE username = ?').get(username);
    if (!admin) return res.status(401).json({ error: 'Invalid credentials.' });

    const valid = bcrypt.compareSync(password, admin.password_hash);
    if (!valid) return res.status(401).json({ error: 'Invalid credentials.' });

    req.session.adminLoggedIn = true;
    req.session.adminUser     = admin.username;
    req.session.adminRole     = admin.role;
    res.json({ success: true, username: admin.username, role: admin.role });
  } catch (e) {
    res.status(500).json({ error: 'Login error.' });
  }
});

router.post('/logout', (req, res) => {
  req.session.destroy();
  res.json({ success: true });
});

router.get('/me', (req, res) => {
  if (!req.session.adminLoggedIn) return res.status(401).json({ error: 'Not logged in' });
  res.json({ username: req.session.adminUser, role: req.session.adminRole });
});

// ─── DASHBOARD STATS ─────────────────────────────────────────
router.get('/stats', requireAdmin, (req, res) => {
  try {
    const totalChecks   = db.prepare('SELECT COUNT(*) as c FROM verification_logs').get().c;
    const trueCount     = db.prepare("SELECT COUNT(*) as c FROM verification_logs WHERE result = 'true'").get().c;
    const falseCount    = db.prepare("SELECT COUNT(*) as c FROM verification_logs WHERE result = 'false'").get().c;
    const pendingRep    = db.prepare("SELECT COUNT(*) as c FROM reports WHERE verdict = 'pending'").get().c;
    const kbCount       = db.prepare("SELECT COUNT(*) as c FROM knowledge_base WHERE status = 'active'").get().c;
    const fakeCount     = db.prepare("SELECT COUNT(*) as c FROM fake_news WHERE status = 'active'").get().c;
    const feedbackCount = db.prepare("SELECT COUNT(*) as c FROM feedback WHERE status = 'unread'").get().c || 0;

    const recentLogs = db.prepare(`
      SELECT query, result, source_used, date_checked
      FROM verification_logs
      ORDER BY date_checked DESC LIMIT 8
    `).all();

    res.json({ totalChecks, trueCount, falseCount, pendingRep, kbCount, fakeCount, feedbackCount, recentLogs });
  } catch (e) {
    res.status(500).json({ error: 'Stats error: ' + e.message });
  }
});

// ─── VERIFICATION LOGS ────────────────────────────────────────
router.get('/logs', requireAdmin, (req, res) => {
  try {
    const logs = db.prepare('SELECT * FROM verification_logs ORDER BY date_checked DESC LIMIT 100').all();
    res.json(logs);
  } catch (e) { res.json([]); }
});

// ─── KNOWLEDGE BASE CRUD ──────────────────────────────────────
router.get('/knowledge', requireAdmin, (req, res) => {
  try {
    res.json(db.prepare('SELECT * FROM knowledge_base ORDER BY id DESC').all());
  } catch (e) { res.json([]); }
});

router.post('/knowledge', requireAdmin, (req, res) => {
  const { title, content, category, source, source_url, date_published } = req.body;
  if (!title || !content) return res.status(400).json({ error: 'Title and content required.' });
  try {
    db.prepare(`
      INSERT INTO knowledge_base (title, content, category, source, source_url, date_published, added_by)
      VALUES (?, ?, ?, ?, ?, ?, ?)
    `).run(title, content, category || 'general', source || 'Admin', source_url || null, date_published || null, req.session.adminUser);
    res.json({ success: true });
  } catch (e) {
    res.status(500).json({ error: 'Failed to add entry.' });
  }
});

router.put('/knowledge/:id', requireAdmin, (req, res) => {
  const { title, content, category, source, status } = req.body;
  try {
    db.prepare(`
      UPDATE knowledge_base SET title=?, content=?, category=?, source=?, status=? WHERE id=?
    `).run(title, content, category, source, status || 'active', req.params.id);
    res.json({ success: true });
  } catch (e) {
    res.status(500).json({ error: 'Failed to update.' });
  }
});

router.delete('/knowledge/:id', requireAdmin, (req, res) => {
  try {
    db.prepare('DELETE FROM knowledge_base WHERE id = ?').run(req.params.id);
    res.json({ success: true });
  } catch (e) {
    res.status(500).json({ error: 'Failed to delete.' });
  }
});

// ─── FAKE NEWS CRUD ───────────────────────────────────────────
router.get('/fakenews', requireAdmin, (req, res) => {
  try {
    res.json(db.prepare('SELECT * FROM fake_news ORDER BY id DESC').all());
  } catch (e) { res.json([]); }
});

router.post('/fakenews', requireAdmin, (req, res) => {
  const { title, content, category, why_false, source_of_rumour } = req.body;
  if (!title || !content || !why_false) return res.status(400).json({ error: 'Title, content and why_false required.' });
  try {
    db.prepare(`
      INSERT INTO fake_news (title, content, category, why_false, source_of_rumour, added_by)
      VALUES (?, ?, ?, ?, ?, ?)
    `).run(title, content, category || 'general', why_false, source_of_rumour || null, req.session.adminUser);
    res.json({ success: true });
  } catch (e) {
    res.status(500).json({ error: 'Failed to add entry.' });
  }
});

router.delete('/fakenews/:id', requireAdmin, (req, res) => {
  try {
    db.prepare('DELETE FROM fake_news WHERE id = ?').run(req.params.id);
    res.json({ success: true });
  } catch (e) {
    res.status(500).json({ error: 'Failed to delete.' });
  }
});

// ─── FEEDBACK (admin view) ────────────────────────────────────
router.get('/feedback', requireAdmin, (req, res) => {
  try {
    res.json(db.prepare('SELECT * FROM feedback ORDER BY date_submitted DESC').all());
  } catch (e) { res.json([]); }
});

module.exports = router;
